#!/bin/sh

./config_and_start_mysql.sh
./config_apache.sh
./config_wordpress.sh
./extract_plugins.sh

alias pena_cmd="sudo -E -u www-data $1"
pena_cmd wp theme activate twentysixteen --path="/var/www/html"

echo "=> Apache started... running on $WP_URL"
/usr/sbin/apache2ctl -D FOREGROUND
