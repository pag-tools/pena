python3 accuracy.py
python3 efficiency.py
python3 wp_experiment.py
