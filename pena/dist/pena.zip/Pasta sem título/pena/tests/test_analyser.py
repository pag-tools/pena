from unittest import TestCase

from tname.core import execution
from tname.core.analyser import Analyser

class TestAnalyser(TestCase):
    pass