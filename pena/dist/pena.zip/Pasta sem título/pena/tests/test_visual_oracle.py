from unittest import TestCase

from tname.core.visual_effects.visual_oracle import VisualOracle

class TestVisualOracle(TestCase):
    pass