#!/usr/bin/env python3
import csv, os, subprocess

FILE = "/pena/subjects/popular_plugins.csv"
WPDIR = "/var/www/html"

PLUGIN_404 = "/pena/subjects/popular_plugins.notfound.csv"

if not os.path.exists(FILE):
    print("Missing input file \"{}\"".format(FILE))
    exit(1)
if not os.path.exists(WPDIR):
    print("Missing Wordpress directory \"{}\"".format(WPDIR))
    exit(1)

with open(FILE) as f, open(PLUGIN_404, 'w') as f_err:
    reader = csv.DictReader(f)
    err_reader = csv.DictWriter(f_err, fieldnames=["name", "version"])
    err_reader.writeheader()
    index, rows = 1, list(reader)
    for row in reader:
        print("Installing {} of {}".format(index, len(rows)))
        install = [
            "wp", "plugin",
            "install", row["name"],
            "--version={}".format(row["version"]),
            "--path={}".format(WPDIR)
        ]
        try:
            print("Error when try to installing: {}. Check if this plugin is available on wordpress website".format(row['name']))
            output = subprocess.check_output(install)
            if 'Error:' in output:
                err_reader.writerow({"name": row["name"], "version": row["version"]})
        except Exception as e:
            err_reader.writerow({"name": row["name"], "version": row["version"]})
        index += 1