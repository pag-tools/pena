#!/usr/bin/env python3 
import logging, ast

from tname.core.execution import Pairwise, SplitSearch
from tname.core.pena import PENA
from experiments.setup import setup

experiment = 'efficiency'

logging.basicConfig(
    level=logging.DEBUG,
    format="%(asctime)s:%(levelname)s:%(funcName)s:%(message)s",
    datefmt="%I:%M:%S %p",
    filename="/pena/experiments/{0}/logs/{0}-PW.log".format(experiment)
)

CONFIGURATION_FILE = '/pena/experiments/{0}/configuration'.format(experiment)
with open(CONFIGURATION_FILE) as configuration:
    plugins = ast.literal_eval(configuration.read())

pena = PENA(cms_path="/var/www/html")
pena.set_mode(Pairwise)
pena.set_skip_dimensionality(True)
pena.visual_oracle = False
pena.remove_spurious = False
pena.show_lines = False

# running sets with Pairwise
for dataset in plugins:
    pena.set_input_plugins(dataset)
    pena.run()


# running sets with SplitSearch

# change log file
[logging.root.removeHandler(handler) for handler in logging.root.handlers[:]]
logging.basicConfig(
    level=logging.DEBUG,
    format="%(asctime)s:%(levelname)s:%(funcName)s:%(message)s",
    datefmt="%I:%M:%S %p",
    filename="/pena/experiments/{0}/logs/{0}-SS.log".format(experiment)
)

pena.set_mode(SplitSearch)
pena.set_skip_dimensionality(True)
pena.visual_oracle = False
pena.remove_spurious = False
pena.show_lines = False

for dataset in plugins:
    pena.set_input_plugins(dataset)

try:
    pena.run()
except:
    pena.cli.deactivate(plugins)
