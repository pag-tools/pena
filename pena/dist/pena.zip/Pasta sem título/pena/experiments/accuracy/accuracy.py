#!/usr/bin/env python3 
import logging, ast

from tname.core.execution import Pairwise, SplitSearch
from tname.core.pena import PENA
from experiments.setup import setup

experiment = 'accuracy'

logging.basicConfig(
    level=logging.DEBUG,
    format="%(asctime)s:%(levelname)s:%(funcName)s:%(message)s",
    datefmt="%I:%M:%S %p",
    filename="/pena/experiments/{0}/logs/{0}.log".format(experiment)
)

CONFIGURATION_FILE = '/pena/experiments/{}/configuration'.format(experiment)

with open(CONFIGURATION_FILE) as configuration:
    plugins = ast.literal_eval(configuration.read())

pena = PENA(cms_path="/var/www/html")

### update settings ###
pena.set_mode(SplitSearch)
pena.set_skip_dimensionality(True)
pena.visual_oracle = False
pena.remove_spurious = True

### add plugins###
pena.set_input_plugins(plugins)
pena.run()