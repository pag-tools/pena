sudo rm /var/www/html/wp-content/plugins/* && sudo rm -rf /var/www/html/wp-content/plugins/*
echo "extracting plugins to wp-plugins folder..."
# sudo tar -xzf /pena/environment/plugins.tar.gz -C /var/www/html/wp-content/plugins --strip-components=1 && sudo rm /pena/environment/plugins.tar.gz
sudo unzip -o -d /var/www/html/wp-content/plugins /pena/environment/plugins.zip && sudo rm /pena/environment/plugins.zip
sudo chmod 755 /var/www/html/wp-content/plugins
echo "extracting plugins to wp-plugins folder... done!"
